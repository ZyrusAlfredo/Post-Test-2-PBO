/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package service;
import model.storage;
import java.util.ArrayList;
/**
 *
 * @author Zyrus
 */
public class CRUD {
    private ArrayList<storage> listStorage = new ArrayList<>();
    private int nextid = 1;
    
    private String format_prioritas(int p){
        switch (p) {
            case 1: return "Tinggi";
            case 2: return "Sedang";
            case 3: return "Rendah";
            default: return "Tidak Valid";
        }
    }
    public void lihat_jadwal(){
        if (listStorage.isEmpty()){
            System.out.println("Belum ada jadwal, ayo buat jadwal mu!");
        }else{
            System.out.println("\n === Daftar ToDoList Kamu ===");
            for (storage s : listStorage){
                s.tampilkan_detail();
            }
        }
    }
    
    public void tambah_jadwal(String kegiatan, String hari, String tanggal, int prioritas){
       storage baru = new storage(nextid, kegiatan, hari, tanggal, prioritas);
       listStorage.add(baru);
        System.out.println("Jadwal berhasil ditambahkan !");
        nextid++;
    }
    
    public void edit_jadwal(int id, String kegiatan, String hari, String tanggal, int prioritas){
        for (storage s : listStorage){
            if (s.getid()==id){
                s.setkegiatan(kegiatan);
                s.sethari(hari);
                s.setanggal(tanggal);
                s.setprioritas(prioritas);
                System.out.println("Jadwal Berhasil diperbarui !");
                return;
            }
        }
        System.out.println("Jadwal dengan nomor" + id + "Tidak ditemukan.");
    }
    public void hapus_jadwal(int id){
        for (storage s : listStorage){
            if (s.getid()==id){
                listStorage.remove(s);
                System.out.println("Jadwal berhasil dihapus !");
                return;
            }
        }
        System.out.println("Jadwal dengan nomor" + id + "Tidak ditemukan.");
    }
    public void search_jadwal(String keyword){
        boolean ditemukan = false;
        for (storage s : listStorage){
            if(s.getkegiatan().toLowerCase().contains(keyword.toLowerCase())){
                s.tampilkan_detail();
                ditemukan = true;
            }
        }
        if(!ditemukan){
            System.out.println("Tidak ada jadwal yang cocok");
        }
    }
}