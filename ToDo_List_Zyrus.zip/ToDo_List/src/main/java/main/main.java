/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package main;
import service.CRUD;
import java.util.Scanner;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

/**
 *
 * @author Zyrus
 */
public class main {
    public static void main(String[]args){
        Scanner input = new Scanner(System.in);
        CRUD service = new CRUD();
        
        System.out.println("Welcome, Ayo Buat To-Do List Kegiatanmu!");
        System.out.println("Tekan ENTER untuk memulai...");
        input.nextLine();
        
        LocalDate today = LocalDate.now();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("EEEE. dd MMMM yyyy");
        System.out.println("Hari ini: " + today.format(formatter));
        
        int pilihan = 0;
        do{
            System.out.println("\n=== PILIHAN MENU TO-DO LIST ===");
            System.out.println("1. Lihat Jadwal");
            System.out.println("2. Tambah Jadwal");
            System.out.println("3. Edit Jadwal");
            System.out.println("4. Hapus Jadwal");
            System.out.println("5. Cari Jadwal");
            System.out.println("6. Keluar");
            System.out.println("Pilih Menu: ");
            
            try{
                pilihan = Integer.parseInt(input.nextLine());
            }catch (NumberFormatException e){
                System.out.println("Harus Berupa Angka !!!");
                continue;
            }
            
            switch (pilihan){
                case 1:
                    service.lihat_jadwal();
                    break;
                    
                case 2:
                    System.out.println("Kegiatan: ");
                    String kegiatan = input.nextLine();
                    
                    String hari;
                    while(true){
                        System.out.println("Hari: ");
                        hari = input.nextLine();
                        if (hari.matches("[a-zA-Z]+")) break;
                        System.out.println("HARUS BERUPA HURUF !!!");
                    }
                    System.out.println("Tangal (DD-MM-YYYY): ");
                    String tanggal = input.nextLine();
                    
                    int prioritas = 0;
                    while(true){
                        System.out.println("Skala Prioritas (1=Tinggi, 2=Sedang, 3=Rendah): ");
                        try{
                            prioritas = Integer.parseInt(input.nextLine());
                            if (prioritas >= 1 && prioritas <= 3) break;
                            else System.out.println("Tidak Valid, silahkan masukkan 1/2/3");
                        }catch (NumberFormatException e){
                            System.out.println("HARUS BERUPA ANGKA!");
                        }
                    }
                    service.tambah_jadwal(kegiatan, hari, tanggal, prioritas);
                    break;
                    
                case 3:
                    System.out.print("Masukkan ID jadwal yang ingin diedit: ");
                    int editid;
                    try {
                        editid = Integer.parseInt(input.nextLine());
                    } catch (NumberFormatException e) {
                        System.out.println("ID harus berupa angka!");
                        break;
                    }
                    System.out.print("Kegiatan: ");
                    String kegiatanBaru = input.nextLine();

                    String hariBaru;
                    while (true) {
                        System.out.print("Hari: ");
                        hariBaru = input.nextLine();
                        if (hariBaru.matches("[a-zA-Z]+")) break;
                        System.out.println("Hari hanya boleh huruf!");
                    }
                    System.out.print("Tanggal baru (dd-mm-yyyy): ");
                    String tanggalBaru = input.nextLine();
                    
                    int prioritasBaru = 0;
                    while (true) {
                        System.out.print("Skala Prioritas (1=Tinggi, 2=Sedang, 3=Rendah): ");
                        try {
                            prioritasBaru = Integer.parseInt(input.nextLine());
                            if (prioritasBaru >= 1 && prioritasBaru <= 3) break;
                            else System.out.println("Prioritas harus 1, 2, atau 3!");
                        } catch (NumberFormatException e) {
                            System.out.println("Prioritas harus berupa angka!");
                        }
                    }
                    service.edit_jadwal(editid, kegiatanBaru, hariBaru, tanggalBaru, prioritasBaru);
                    break;
                    
                case 4:
                    System.out.println("Masukkan ID jadwal yang ingin dihapus:  ");
                    int hapusid = input.nextInt();
                    input.nextLine();
                    service.hapus_jadwal(hapusid);
                    break;
                    
                case 5:
                    System.out.println("Masukkan jadwal yang ingin dicari: ");
                    String keyword = input.nextLine();
                    service.search_jadwal(keyword);
                    break;
                    
                case 6:
                    System.out.println("Terimakasih, Tetap Semangat & Happy Nice Day");
                    break;
                    
                default:
                    System.out.println("Pilihan tidak valid, coba lagi!");
            }
        }while (pilihan != 6);
        
        input.close();
    }
    
}