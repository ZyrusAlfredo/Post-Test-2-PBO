/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package model;

/**
 *
 * @author Zyrus
 */
public class storage {

    private int id;
    private String kegiatan;
    private String hari;
    private String tanggal;
    private int prioritas;
    
    public storage (int id, String kegiatan, String hari, String tanggal, int prioritas) {
        this.id = id;
        this.kegiatan = kegiatan;
        this.hari = hari;
        this.tanggal = tanggal;
        this.prioritas = prioritas;
    }
    
    public int getid() {return id;}
    public String getkegiatan() {return kegiatan;}
    public void setkegiatan(String kegiatan) {this.kegiatan = kegiatan;}
    public String gethari() {return hari;}
    public void sethari(String hari) {this.hari = hari;}
    public String gettanggal() {return tanggal;}
    public void setanggal(String tanggal) {this.tanggal = tanggal;}
    public int getprioritas() {return prioritas;}
    public void setprioritas(int prioritas) {this.prioritas = prioritas;}
    
    public void tampilkan_detail(){
        System.out.println("ID: " + id);
        System.out.println("Kegiatan: " + kegiatan);
        System.out.println("Hari: " + hari);
        System.out.println("Tanggal: " + tanggal);
        System.out.println("Prioritas: " + formatPrioritas(prioritas));
    }
    private String formatPrioritas(int p){
        switch (p){
            case 1: return "Tinggi";
            case 2: return "Sedang";
            case 3: return "Rendah";
            default: return "Tidak Valid";
        }
    }
}